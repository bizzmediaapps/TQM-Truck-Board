# Soccer Scoreboard

Deploy on Vercel and connect to GitHub for dynamic updates.
